<div class="side-header show">
    <button class="side-header-close"><i class="zmdi zmdi-close"></i></button>
    <!-- Side Header Inner Start -->
    <div class="side-header-inner custom-scroll">

        <nav class="side-header-menu" id="side-header-menu">
            <ul>
                <li class="has-sub-menu"><a href="#"><i class="ti-home"></i><span>Dashboard</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="index.php"><span>E-commerce (Default)</span></a></li>
                        <li><a href="index-crypto.php"><span>Cryptocurrency</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Products</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-product.php"><span>Add Product</span></a></li>
                        <li><a href="add-category.php"><span>Add Category</span></a></li>
                        <li><a href="invoice-list.php"><span>Invoice List</span></a></li>
                        <li><a href="invoice-details.php"><span>Invoice Details</span></a></li>
                        <li><a href="order-list.php"><span>Order List</span></a></li>
                        <li><a href="order-details.php"><span>Order Details</span></a></li>
                        <li><a href="manage-products.php"><span>Manage Products</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Testimonials</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-testimonial.php"><span>Add Testimonial</span></a></li>
                        <li><a href="manage-testimonials.php"><span>Manage Testimonials</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Discounts</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-coupons.php"><span>Add Coupons</span></a></li>
                        <li><a href="manage-coupons.php"><span>Manage Coupons</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Team</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-team.php"><span>Add Team</span></a></li>
                        <li><a href="edit-product.php"><span>Edit Team</span></a></li>
                        <li><a href="manage-teams.php"><span>Manage Team</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Blogs</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-blog.php"><span>Add Blog</span></a></li>
                        <li><a href="add-blog-editor.php"><span>Add Blog Editor</span></a></li>
                        <li><a href="manage-blogs.php"><span>Manage Blogs</span></a></li>
                        <li><a href="manage-editors.php"><span>Manage Editors</span></a></li>
                    </ul>
                </li>
                <li class="has-sub-menu"><a href="#"><i class="ti-shopping-cart"></i> <span>Portfolio</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="add-portfolio.php"><span>Add Portfolio</span></a></li>
                        <li><a href="manage-portfolio.php"><span>Manage Products</span></a></li>
                    </ul>
                </li>
                <li><a href="todo-list.php"><i class="ti-palette"></i> <span>TODO-list</span></a></li>
                <li class="has-sub-menu"><a href="#"><i class="ti-layers"></i> <span>Pages</span></a>
                    <ul class="side-header-sub-menu">
                        <li><a href="blank.php"><span>About us</span></a></li>
                        <li><a href="contact-us.php"><span>Contact us</span></a></li>
                    </ul>
                </li>

            </ul>
        </nav>
    </div>
    <!-- Side Header Inner End -->
</div>
