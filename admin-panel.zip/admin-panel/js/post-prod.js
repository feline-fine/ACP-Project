document.getElementById('addprodform').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission
    // Get form data using FormData
    const formData = new FormData(event.target);

    // Extract the file name from the 'prod-img' file input
    const prodImgFile = formData.get('prod-img');
    const prodImgFileName = prodImgFile instanceof File ? prodImgFile.name : '';

    // Create an object in the required format
    const dataObject = {
        "category": {
            "categoryId": formData.get('cat-id'),
            // Add other category properties if needed
        },
        "name": formData.get('name'),
        "description": formData.get('desc'),
        "price": formData.get('price'),
        "image": prodImgFileName,
        "onSale": true, // Assuming 'publish' is the value for onSale
        "quantityInStock": formData.get('in-stock'),
        "sku": formData.get('sku'),
        "sales": formData.get('sales'),
        "status": formData.get('status'),
        "date": new Date().toISOString().split('T')[0], // Current date
        "info1": formData.get('info-1'),
        "info2": formData.get('info-2'),
        "info3": formData.get('info-3'),
        "info4": formData.get('info-4')
    };

    fetch('http://localhost:8080/api/plantify/add-product', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataObject),
    })
        .then(response => {
            // Check if the response status is OK
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            // Since we don't expect a JSON response, return an empty object
            return {};
        })
        .then(data => {
            console.log('Success:', data);
            // Handle success, e.g., show a success message to the user
        })
        .catch((error) => {
            console.error('Error:', error.message);
            // Handle errors, e.g., show an error message to the user
        });
});
