document.getElementById('addblogform').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    // Get form data using FormData
    const formData = new FormData(event.target);

    // Extract the file name from the 'dp' file input
    const dpFile = formData.get('dp');
    const dpFileName = dpFile instanceof File ? dpFile.name : '';

    // Create an object in the required format
    const dataObject = {
        headerLine: formData.get('header'),
        content: formData.get('content'),
        blogQuote: formData.get('quote'),
        editorId: {
            editorId: formData.get('editor')
        },
        headImage: dpFileName,
        creationDate: new Date().toISOString().split('T')[0]
    };

    fetch('http://localhost:8080/api/plantify/add-blog', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        // Check if the response status is OK
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Since we don't expect a JSON response, return an empty object
        return {};
    })
    .then(data => {
        console.log('Success:', data);
        // Handle success, e.g., show a success message to the user
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });

});