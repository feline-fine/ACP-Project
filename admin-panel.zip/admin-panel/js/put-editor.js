// Extract editorId from the URL
const urlParams = new URLSearchParams(window.location.search);
const editorId = urlParams.get('editorId');

document.addEventListener('DOMContentLoaded', function () {
    // Fetch blog details based on the memberId
    fetch(`http://localhost:8080/api/plantify/editors/${editorId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(editor => {
            // Update HTML content with fetched data
            console.log(editor);
            
            document.querySelector('input[name="name"]').value = editor.name;
            document.querySelector('input[name="email"]').value = editor.email;
            document.querySelector('input[name="contact"]').value = editor.contact;
            document.querySelector('textarea[name="note"]').value = editor.editorNote;

            // Set the file input label or show the filename
            const fileInput = document.querySelector('input[name="dp"]');
            const fileNameLabel = document.querySelector('.form-help-text');

            if (editor.editorDp) {
                fileNameLabel.textContent = `Selected file: ${editor.editorDp}`;
            }
        })
        .catch(error => {
            console.error('Error fetching team details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-editor-form'));
    // Extract the file name from the 'prod-img' file input
    const dpFile = formData.get('dp');
    const dpFileName = dpFile instanceof File ? dpFile.name : '';

    const dataObject = {
        name: formData.get('name'),
        editorDp: dpFileName,
        email: formData.get('email'),
        editorNote: formData.get('note'),
        contact: formData.get('contact')
      };

    console.log(`editor id: ${editorId}`);

    fetch(`http://localhost:8080/api/plantify/update-editor/${editorId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            // "Access-Control-Allow-Origin" : "*", 
            // "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


