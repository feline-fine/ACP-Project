const urlParams = new URLSearchParams(window.location.search);
const prodId = urlParams.get('productId');
document.addEventListener('DOMContentLoaded', function () {
    // Extract memberId from the URL
    

    // Fetch blog details based on the memberId
    fetch(`http://localhost:8080/api/plantify/products/${prodId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(prod => {
            // Update HTML content with fetched data
            console.log(prod);
            
            document.querySelector('input[name="name"]').value = prod.name;
            document.querySelector('input[name="price"]').value = prod.price;
            document.querySelector('input[name="on-sale"]').value = prod.onSale;
            document.querySelector('input[name="in-stock"]').value = prod.quantityInStock;
            document.querySelector('input[name="sku"]').value = prod.sku;
            document.querySelector('input[name="sales"]').value = prod.sales;
            document.querySelector('textarea[name="desc"]').value = prod.description;
            // Set the selected option based on the product's status.
            const selectElement = document.querySelector('select[name="status"]');
            const optionStatus = selectElement.options;
            for (let i = 0; i < optionStatus.length; i++) {
                if (optionStatus[i].value === prod.status) {
                    optionStatus[i].selected = true;
                    break;
                }
            }
            // Set the selected option based on the product's category.
            const selectCat = document.querySelector('select[name="cat-id"]');
            const options = selectElement.options;
            for (let i = 0; i < options.length; i++) {
                if (options[i].value === prod.category.catId) {
                    options[i].selected = true;
                    break;
                }
            }
            document.querySelector('input[name="info-1"]').value = prod.info1;
            document.querySelector('input[name="info-2"]').value = prod.info2;
            document.querySelector('input[name="info-3"]').value = prod.info3;
            document.querySelector('input[name="info-4"]').value = prod.info4;

            // Set the file input label or show the filename
            const fileInput = document.querySelector('input[name="prod-img"]');
            const fileNameLabel = document.querySelector('.form-help-text');

            if (prod.image) {
                fileNameLabel.textContent = `Selected file: ${prod.image}`;
            }
        })
        .catch(error => {
            console.error('Error fetching team details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    console.log(`cat id: ${prodId}`)
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-prod-form'));

    const prodImgFile = formData.get('prod-img');
    const prodImgFileName = prodImgFile instanceof File ? prodImgFile.name : '';

    const dataObject = {
        "category": {
            "categoryId": formData.get('cat-id'),
            // Add other category properties if needed
        },
        "name": formData.get('name'),
        "description": formData.get('desc'),
        "price": formData.get('price'),
        "image": prodImgFileName,
        "onSale": true, // Assuming 'publish' is the value for onSale
        "quantityInStock": formData.get('in-stock'),
        "sku": formData.get('sku'),
        "sales": formData.get('sales'),
        "status": formData.get('status'),
        "date": new Date().toISOString().split('T')[0], // Current date
        "info1": formData.get('info-1'),
        "info2": formData.get('info-2'),
        "info3": formData.get('info-3'),
        "info4": formData.get('info-4')
    };

    

    fetch(`http://localhost:8080/api/plantify/update-product/${prodId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            // "Access-Control-Allow-Origin" : "*", 
            // "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


