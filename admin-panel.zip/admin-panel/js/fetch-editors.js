function deleteEditor(editorId) {
    // Confirm with the user before deleting the blog
    const isConfirmed = confirm('Are you sure you want to delete this blog?');

    if (isConfirmed) {
        // Send a DELETE request to your API to delete the blog with the specified ID
        fetch(`http://localhost:8080/api/plantify/delete-editor/${editorId}`, {
            method: 'DELETE',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Reload the page or update the blog list after successful deletion
            location.reload();
        })
        .catch(error => {
            console.error('Error during delete operation:', error);
        });
    }
}

//click on update button.
function updateClick(editorId) {
    // Construct the URL with the blogId
    const updateEditorURL = `update-blog-editor.html?editorId=${editorId}`;
    // Navigate to the single-post.html page
    window.location.href = updateEditorURL;
}


function fetchEditors() {
    fetch('http://localhost:8080/api/plantify/editors', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(editors => {
            // Handle the retrieved data
            console.log(editors);

            // Select the containers for blog posts and pagination
            let editorTable = document.getElementById('editor-table');

            // Loop through the data and create HTML elements for each blog
            editors.forEach(editor => {
                // Create a new blog element
                let editorRow = document.createElement('tr');
                editorRow.innerHTML = `
                    <tr>
                        <td><img src='assets/images/editor/${editor.editorDp}' alt='Editor Image' class="product-image rounded-circle" height="70" width="70"></td>
                        <td><a href="#">${editor.name}</a></td>
                        <td>${editor.email}</td>
                        <td>${editor.editorNote}</td>
                        <td>${editor.contact}</td>
                        <td>
                            <div class="table-action-buttons">
                                <a class="view button button-box button-xs button-primary" href="invoice-details.html"><i class="zmdi zmdi-more"></i></a>
                                <a class="edit button button-box button-xs button-info" href="#" onclick="updateClick(${editor.editorId})"><i class="zmdi zmdi-edit"></i></a>
                                <a class="delete button button-box button-xs button-danger" href=# onclick="deleteEditor(${editor.editorId})"><i class="zmdi zmdi-delete"></i></a>
                            </div>
                        </td>
                    </tr>
                `;

                // Append the blog post to the blog container
                editorTable.appendChild(editorRow);
            });

            // Move the pagination container to the bottom
            //blogContainer.parentNode.insertBefore(paginationContainer, blogContainer.nextSibling);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

//contact


// Call the fetchBlogs function when the page loads or as needed
window.onload = function() {
    fetchEditors();
};