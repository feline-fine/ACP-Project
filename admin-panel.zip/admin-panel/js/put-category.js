const urlParams = new URLSearchParams(window.location.search);
    const catId = urlParams.get('categoryId');
document.addEventListener('DOMContentLoaded', function () {
    // Extract memberId from the URL
    

    // Fetch blog details based on the memberId
    fetch(`http://localhost:8080/api/plantify/categories/${catId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(cat => {
            // Update HTML content with fetched data
            console.log(cat);
            
            document.querySelector('input[name="name"]').value = cat.name;
            document.querySelector('textarea[name="desc"]').value = cat.description;
        })
        .catch(error => {
            console.error('Error fetching team details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    console.log(`cat id: ${catId}`)
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-cat-form'));

    const dataObject = {
        "name": formData.get('name'),
        "description": formData.get('desc')
    };

    

    fetch(`http://localhost:8080/api/plantify/update-cat/${catId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            "Access-Control-Allow-Origin" : "*", 
            "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


