function fetchCategoriesAndPopulateDropdown() {
    const selectDropdown = document.getElementById('cat-id');

    fetch('http://localhost:8080/api/plantify/categories', {
        method: 'GET',
        headers: {
            'content-type': 'application/json',
            // Add any other headers as needed
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(categories => {
        // Clear existing options
        //selectDropdown.innerHTML = "";

        // Populate the dropdown with category names
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.categoryId;
            option.text = category.name;
            selectDropdown.appendChild(option);
        });
    })
    .catch(error => {
        console.error('Error during fetch operation:', error);
    });
}

// Call the function to fetch and populate categories
window.onload = function() {
    fetchCategoriesAndPopulateDropdown();
};