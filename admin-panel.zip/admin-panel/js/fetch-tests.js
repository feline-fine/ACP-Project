function deleteTest(testId) {
    // Confirm with the user before deleting the blog
    const isConfirmed = confirm('Are you sure you want to delete this member?');

    if (isConfirmed) {
        // Send a DELETE request to your API to delete the blog with the specified ID
        fetch(`http://localhost:8080/api/plantify/delete-test/${testId}`, {
            method: 'DELETE',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Reload the page or update the blog list after successful deletion
            location.reload();
        })
        .catch(error => {
            console.error('Error during delete operation:', error);
        });
    }
}

//click on update button.
function updateClick(testId) {
    // Construct the URL with the blogId
    const updateTestURL = `update-testimonial.html?testId=${testId}`;
    // Navigate to the single-post.html page
    window.location.href = updateTestURL;
}

function fetchTestimonials() {
    fetch('http://localhost:8080/api/plantify/testimonials', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(testimonials => {
        // Handle the retrieved data
        console.log(testimonials);

        // Select the testimonials container
        let testTable = document.getElementById('test-table');

        // Loop through the data and create HTML elements for each testimonial
        testimonials.forEach(testimonial => {
            // Create a new testimonial element
            let testRow = document.createElement('tr');

            // HTML template for a testimonial
            testRow.innerHTML = `
                <tr>
                    <td><img src="assets/images/test/${testimonial.personDp}" alt="" class="product-image rounded-circle" height="70" width="70"></td>
                    <td><a href="#">${testimonial.personName}</a></td>
                    <td>${testimonial.personJob}</td>
                    <td>${testimonial.company}</td>
                    <td>${testimonial.review}</td>
                    <td>
                        <div class="table-action-buttons">
                            <a class="view button button-box button-xs button-primary" href="invoice-details.html"><i class="zmdi zmdi-more"></i></a>
                            <a class="edit button button-box button-xs button-info" href="#" onclick="updateClick(${testimonial.testId})"><i class="zmdi zmdi-edit"></i></a>
                            <a class="delete button button-box button-xs button-danger" href="#" onclick="deleteTest(${testimonial.testId})"><i class="zmdi zmdi-delete"></i></a>
                        </div>
                    </td>
                </tr>
            `;

            // Append the testimonial to the testimonials container
            testTable.appendChild(testRow);
        });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// Call the fetchTestimonials function when the page loads or as needed
window.onload = function() {
    fetchTestimonials();
};