// Extract testId from the URL
const urlParams = new URLSearchParams(window.location.search);
const testId = urlParams.get('testId');
document.addEventListener('DOMContentLoaded', function () {
    // Fetch blog details based on the testId
    fetch(`http://localhost:8080/api/plantify/testimonials/${testId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(test => {
            // Update HTML content with fetched data
            console.log(test);
            
            document.querySelector('input[name="name"]').value = test.personName;
            document.querySelector('input[name="company"]').value = test.company;
            document.querySelector('textarea[name="review"]').value = test.review;
            // Set the selected option based on the member's position
            const selectElement = document.querySelector('select[name="job-pos"]');
            const options = selectElement.options;
            for (let i = 0; i < options.length; i++) {
                if (options[i].value === test.personJob) {
                    options[i].selected = true;
                    break;
                }
            }
            // Set the selected option based on the member's position
            const selectGender = document.querySelector('select[name="gender"]');
            const option = selectGender.options;
            for (let i = 0; i < option.length; i++) {
                if (option[i].value === test.gender) {
                    option[i].selected = true;
                    break;
                }
            }
            // Set the file input label or show the filename
            const fileInput = document.querySelector('input[name="dp"]');
            const fileNameLabel = document.querySelector('.form-help-text');

            if (test.personDp) {
                fileNameLabel.textContent = `Selected file: ${test.personDp}`;
            }
        })
        .catch(error => {
            console.error('Error fetching team details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-test-form'));
    // Extract the file name from the 'prod-img' file input
    const dpFile = formData.get('dp');
    const dpFileName = dpFile instanceof File ? dpFile.name : '';

    const dataObject = {
        personName: formData.get('name'),
        personDp: dpFileName,
        personJob: formData.get('job-pos'),
        company: formData.get('company'),
        review: formData.get('review'),
        gender: formData.get('gender')
    };

    console.log(`mem id: ${testId}`);

    fetch(`http://localhost:8080/api/plantify/update-testimonial/${testId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            // "Access-Control-Allow-Origin" : "*", 
            // "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


