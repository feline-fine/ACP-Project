function deleteProduct(prodId) {
    // Confirm with the user before deleting the blog
    const isConfirmed = confirm('Are you sure you want to delete this blog?');

    if (isConfirmed) {
        // Send a DELETE request to your API to delete the blog with the specified ID
        fetch(`http://localhost:8080/api/plantify/delete-product/${prodId}`, {
            method: 'DELETE',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Reload the page or update the blog list after successful deletion
            location.reload();
        })
        .catch(error => {
            console.error('Error during delete operation:', error);
        });
    }
}

//click on update button.
function updateClick(prodId) {
    // Construct the URL with the blogId
    const updateProdURL = `update-product.html?productId=${prodId}`;
    // Navigate to the single-post.html page
    window.location.href = updateProdURL;
}

function fetchProducts() {
    fetch('http://localhost:8080/api/plantify/products', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(products => {
            // Handle the retrieved data
            console.log(products);

            // Select the containers for blog posts and pagination
            let prodTable = document.getElementById('prod-table');

            // Loop through the data and create HTML elements for each blog
            products.forEach(product => {
                // Create a new blog element
                let prodRow = document.createElement('tr');
                prodRow.innerHTML = `
                    <tr>
                        <td>#${product.sku}</td>
                        <td><img src='assets/images/product/${product.image}' alt='Product Image' class="product-image rounded-circle" height="70" width="70"></td>
                        <td><a href="#">${product.name}</a></td>
                        <td>${product.price}</td>
                        <td>${product.sales}</td>
                        <td>${product.status}</td>
                        <td>${product.date}</td>
                        <td><span class="badge badge-danger">${product.onSale}</span></td>
                        <td>
                            <div class="table-action-buttons">
                                <a class="view button button-box button-xs button-primary" href="invoice-details.html"><i class="zmdi zmdi-more"></i></a>
                                <a class="edit button button-box button-xs button-info" href="#" onclick="updateClick(${product.productId})"><i class="zmdi zmdi-edit"></i></a>
                                <a class="delete button button-box button-xs button-danger" href="#" onclick="deleteProduct(${product.productId})"><i class="zmdi zmdi-delete"></i></a>
                            </div>
                        </td>
                    </tr>
                `;

                // Append the prod row to the prob Table.
                prodTable.appendChild(prodRow);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}


// Call the fetchProducts function when the page loads or as needed
window.onload = function() {
    fetchProducts();
};