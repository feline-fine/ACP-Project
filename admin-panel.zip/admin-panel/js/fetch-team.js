function deleteTeam(memberId) {
    // Confirm with the user before deleting the blog
    const isConfirmed = confirm('Are you sure you want to delete this member?');

    if (isConfirmed) {
        // Send a DELETE request to your API to delete the blog with the specified ID
        fetch(`http://localhost:8080/api/plantify/delete-member/${memberId}`, {
            method: 'DELETE',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            // Reload the page or update the blog list after successful deletion
            location.reload();
        })
        .catch(error => {
            console.error('Error during delete operation:', error);
        });
    }
}

//click on update button.
function updateClick(memberId) {
    // Construct the URL with the blogId
    const updateTeamURL = `update-team.html?memberId=${memberId}`;
    // Navigate to the single-post.html page
    window.location.href = updateTeamURL;
}


function fetchTeam() {
    fetch('http://localhost:8080/api/plantify/team', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Handle the retrieved data
            console.log(data);

            // Select the team container
            let teamTable = document.getElementById('team-table');

            // Loop through the data and create HTML elements for each team member
            data.forEach(member => {
                // Create a new team member element
                let teamRow = document.createElement('tr');

                // HTML template for a team member
                teamRow.innerHTML = `
                    <tr>
                        <td><img src='assets/images/team/${member.memberPic}' alt='Product Image' class="product-image rounded-circle" height="70" width="70"></td>
                        <td><a href="#">${member.name}</a></td>
                        <td>${member.email}</td>
                        <td>${member.contact}</td>
                        <td>${member.position}</td>
                        <td>
                            <div class="table-action-buttons">
                                <a class="view button button-box button-xs button-primary" href="invoice-details.html"><i class="zmdi zmdi-more"></i></a>
                                <a class="edit button button-box button-xs button-info" href="#" onclick="updateClick(${member.memberId})"><i class="zmdi zmdi-edit"></i></a>
                                <a class="delete button button-box button-xs button-danger" href="#" onclick="deleteTeam(${member.memberId})"><i class="zmdi zmdi-delete"></i></a>
                            </div>
                        </td>
                    </tr>
                `;

                // Append the team member to the team container
                teamTable.appendChild(teamRow);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

window.onload = function() {
    fetchTeam();
};