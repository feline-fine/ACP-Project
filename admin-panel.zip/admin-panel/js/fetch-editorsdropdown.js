// Function to fetch the list of editors and populate the select element
function fetchEditors() {
    fetch('http://localhost:8080/api/plantify/editors', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(editors => {
            // Handle the retrieved data
            populateEditorSelect(editors);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// Function to populate the editor select element
function populateEditorSelect(editors) {
    const editorSelect = document.getElementById('editor');

    // Clear existing options
    editorSelect.innerHTML = '';

    // Add a default option
    const defaultOption = document.createElement('option');
    defaultOption.text = 'Select Editor';
    editorSelect.add(defaultOption);

    // Add each editor to the select element
    editors.forEach(editor => {
        const option = document.createElement('option');
        option.value = editor.editorId;
        option.text = editor.name;
        editorSelect.add(option);
    });
}

window.onload = function() {
    fetchEditors();
};
