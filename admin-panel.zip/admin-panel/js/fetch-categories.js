// function deleteProduct(prodId) {
//     // Confirm with the user before deleting the blog
//     const isConfirmed = confirm('Are you sure you want to delete this blog?');

//     if (isConfirmed) {
//         // Send a DELETE request to your API to delete the blog with the specified ID
//         fetch(`http://localhost:8080/api/plantify/delete-product/${prodId}`, {
//             method: 'DELETE',
//             headers: {
//                 'content-type': 'application/json',
//                 // Add any other headers as needed
//             },
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             // Reload the page or update the blog list after successful deletion
//             location.reload();
//         })
//         .catch(error => {
//             console.error('Error during delete operation:', error);
//         });
//     }
// }

//click on update button.
function updateClick(catId) {
    // Construct the URL with the blogId
    const updateCatURL = `update-categories.html?categoryId=${catId}`;
    // Navigate to the single-post.html page
    window.location.href = updateCatURL;
}


function fetchCategories() {
    fetch('http://localhost:8080/api/plantify/categories', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(cats => {
            // Handle the retrieved data
            console.log(cats);

            // Select the containers for blog posts and pagination
            let catTable = document.getElementById('cat-table');

            // Loop through the data and create HTML elements for each blog
            cats.forEach(cat => {
                // Create a new blog element
                let catRow = document.createElement('tr');
                catRow.innerHTML = `
                    <tr>
                        <td>${cat.name}</td>
                        <td>${cat.description}</td>
                        <td>
                            <div class="table-action-buttons">
                                <a class="view button button-box button-xs button-primary" href="invoice-details.html"><i class="zmdi zmdi-more"></i></a>
                                <a class="edit button button-box button-xs button-info" href="#" onclick="updateClick(${cat.categoryId})"><i class="zmdi zmdi-edit"></i></a>
                                <a class="delete button button-box button-xs button-danger" href="#"><i class="zmdi zmdi-delete"></i></a>
                            </div>
                        </td>
                    </tr>
                `;

                // Append the prod row to the prob Table.
                catTable.appendChild(catRow);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}


// Call the fetchProducts function when the page loads or as needed
window.onload = function() {
    fetchCategories();
};