// Extract blogId from the URL
const urlParams = new URLSearchParams(window.location.search);
const blogId = urlParams.get('blogId');

document.addEventListener('DOMContentLoaded', function () {
    // Fetch blog details based on the memberId
    fetch(`http://localhost:8080/api/plantify/blogs/${blogId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(blog => {
            // Update HTML content with fetched data
            console.log(blog);
            
            document.querySelector('input[name="header"]').value = blog.headerLine;
            document.querySelector('textarea[name="content"]').value = blog.content;
            document.querySelector('textarea[name="quote"]').value = blog.blogQuote;
            // Set the selected option based on the member's position
            const selectElement = document.querySelector('select[name="editor"]');
            const options = selectElement.options;
            for (let i = 0; i < options.length; i++) {
                if (options[i].value === blog.editorId.editorId) {
                    options[i].selected = true;
                    break;
                }
            }
            // Set the file input label or show the filename
            const fileInput = document.querySelector('input[name="dp"]');
            const fileNameLabel = document.querySelector('.form-help-text');

            if (blog.headImage) {
                fileNameLabel.textContent = `Selected file: ${blog.headImage}`;
            }
        })
        .catch(error => {
            console.error('Error fetching blog details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-blog-form'));
    // Extract the file name from the 'prod-img' file input
    const dpFile = formData.get('dp');
    const dpFileName = dpFile instanceof File ? dpFile.name : '';

    const dataObject = {
        headerLine: formData.get('header'),
        content: formData.get('content'),
        blogQuote: formData.get('quote'),
        editorId: {
            editorId: formData.get('editor')
        },
        headImage: dpFileName,
        creationDate: new Date().toISOString().split('T')[0]
    };

    console.log(`blog id: ${blogId}`);

    fetch(`http://localhost:8080/api/plantify/update-blog/${blogId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            // "Access-Control-Allow-Origin" : "*", 
            // "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


