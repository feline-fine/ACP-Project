document.addEventListener('DOMContentLoaded', function () {
    // Extract memberId from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const memberId = urlParams.get('memberId');

    // Fetch blog details based on the memberId
    fetch(`http://localhost:8080/api/plantify/team/${memberId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(member => {
            // Update HTML content with fetched data
            console.log(member);
            
            document.querySelector('input[name="name"]').value = member.name;
            document.querySelector('input[name="email"]').value = member.email;
            document.querySelector('input[name="contact"]').value = member.contact;
            // Set the selected option based on the member's position
            const selectElement = document.querySelector('select[name="job-pos"]');
            const options = selectElement.options;
            for (let i = 0; i < options.length; i++) {
                if (options[i].value === member.position) {
                    options[i].selected = true;
                    break;
                }
            }
            // Set the file input label or show the filename
            const fileInput = document.querySelector('input[name="dp"]');
            const fileNameLabel = document.querySelector('.form-help-text');

            if (member.memberPic) {
                fileNameLabel.textContent = `Selected file: ${member.memberPic}`;
            }
        })
        .catch(error => {
            console.error('Error fetching team details:', error);
        });
});

function saveAndPublish(event) {
    console.log('Save and publish function called');
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(document.getElementById('update-team-form'));
    // Extract the file name from the 'prod-img' file input
    const dpFile = formData.get('dp');
    const dpFileName = dpFile instanceof File ? dpFile.name : '';

    const dataObject = {
       
        name : formData.get('name'),
        "email": formData.get('email'),
        "contact": formData.get('contact'),
        "position": formData.get('job-pos'),
        "memberPic": dpFileName,
    };
    console.log( dataObject.email );
    console.log( dataObject.contact );
    console.log( dataObject.position );
    console.log( dataObject.memberPic );
    const urlParams = new URLSearchParams(window.location.search);
    const memberId = urlParams.get('memberId');

    console.log(`mem id: ${memberId}`);

    fetch(`http://localhost:8080/api/plantify/update-member/${memberId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            // "Access-Control-Allow-Origin" : "*", 
            // "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error.message);
    });
}


