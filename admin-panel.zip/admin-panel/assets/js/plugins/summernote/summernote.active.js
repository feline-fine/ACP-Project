(function ($) {
    "use strict";
    
    /*Summernote*/
    if( $('.summernote').length ) {
        $('.summernote').summernote({
            height: 250,
        });
    }
    
})(jQuery);