package com.demo.plantify;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping(path="/api/plantify")
public class PlantifyController {
	
	@Autowired
	private final PlantifyService plantifyService;
	
	public PlantifyController(PlantifyService blogService) {
		super();
		this.plantifyService = blogService;
	}
	
	//team
	@GetMapping("team")
	public List<Team> getTeam(){
		return plantifyService.getTeam();
	}
	
	@GetMapping("team/{id}")
	public Team getTeamById(@PathVariable Long id){
		return plantifyService.getTeamById(id);
	}
	
	@PostMapping("add-member")
	public void addTeam(@RequestBody Team team) {
		plantifyService.addTeam(team);
	}
	
	@DeleteMapping("delete-member/{id}")
	public void deleteTeam(@PathVariable Long id) {
		plantifyService.deleteTeam(id);
	}
	
	@PutMapping("update-member/{id}")
	public void updateMember(@RequestBody Team member , @PathVariable Long id ){
		plantifyService.updateTeam(member, id);
	}
	
	//testimonials
	@GetMapping("testimonials")
	public List<Testimonial> getTest(){
		return plantifyService.getTest();
	}
	
	@GetMapping("testimonials/{id}")
	public Testimonial getTestById(@PathVariable Long id){
		return plantifyService.getTestById(id);
	}
	
	@PostMapping("add-test")
	public void addTest(@RequestBody Testimonial test) {
		plantifyService.addTest(test);
	}
	
	@DeleteMapping("delete-test/{id}")
	public void deleteTest(@PathVariable Long id) {
		plantifyService.deleteTest(id);
	}
	
	@PutMapping("update-testimonial/{id}")
	public void updateTestimonial(@RequestBody Testimonial test , @PathVariable Long id ){
		plantifyService.updateTest(test, id);
	}
	
	//blog
	@GetMapping("blogs")
	public List<Blog> getBlogs(){
		return plantifyService.getBlog();
	}
	
	@GetMapping("blogs/{id}")
	public Blog getBlogById(@PathVariable Long id){
		return plantifyService.getBlogById(id);
	}
	
	@GetMapping("recent-blogs")
	public List<Blog> getRecentBlogs(){
		return plantifyService.getRecentBlogs();
	}
	
	@PostMapping("add-blog")
	public void addBlog(@RequestBody Blog blog) {
		plantifyService.addBlog(blog);
	}
	
	@DeleteMapping("delete-blog/{id}")
	public void deleteBlog(@PathVariable Long id) {
		plantifyService.deleteBlog(id);
	}
	
	@PutMapping("update-blog/{id}")
	public void updateBlog(@RequestBody Blog blog , @PathVariable Long id ){
		plantifyService.updateBlog(blog, id);
	}
	
	//editor
	@GetMapping("editors")
	public List<Editor> getEditors(){
		return plantifyService.getEditor();
	}
	
	@GetMapping("editors/{id}")
	public Editor getEditorById(@PathVariable Long id){
		return plantifyService.getEditorById(id);
	}
	
	@PostMapping("add-editor")
	public void addEditor(@RequestBody Editor editor) {
		plantifyService.addEditor(editor);
	}
	
	@DeleteMapping("delete-editor/{id}")
	public void deleteEditor(@PathVariable Long id) {
		plantifyService.deleteEditor(id);
	}
	
	@PutMapping("update-editor/{id}")
	public void updateEditor(@RequestBody Editor editor , @PathVariable Long id ){
		plantifyService.updateEditor(editor, id);
	}
	
	//category
	@GetMapping("categories")
	public List<Category> getCategory(){
		return plantifyService.getCategory();
	}
	
	@GetMapping("categories/{id}")
	public Category getCategoryById(@PathVariable Long id){
		return plantifyService.getCategoryById(id);
	}
	
	@PostMapping("add-category")
	public void addCategory(@RequestBody Category cat) {
		plantifyService.addCategory(cat);
	}
	
	@PutMapping("update-cat/{id}")
	public void updateCategory(@RequestBody Category cat , @PathVariable Long id ){
		plantifyService.updateCategory(cat, id);
	}
	
	@DeleteMapping("delete-cat/{id}")
	public void deleteCategory(@PathVariable Long id) {
		plantifyService.deleteCategory(id);
	}
	
	//product
	@GetMapping("products")
	public List<Product> getProducts(){
		return plantifyService.getProduct();
	}
	
	@GetMapping("products-best-3")
	public List<Product> getTop3ProductsBySales(){
		return plantifyService.getTop3ProductsBySales();
	}
	
	@GetMapping("products-best-4")
	public List<Product> getTop4ProductsByDate(){
		return plantifyService.getTop4ProductsByDate();
	}
	
	@GetMapping("products/{id}")
	public Product getProdById(@PathVariable Long id){
		return plantifyService.getProdById(id);
	}
	
	@GetMapping("product/{id}")
	public List<Product> getProdByCatId(@PathVariable Long id){
		return plantifyService.getProductsByCategoryId(id);
	}
	
	@PostMapping("add-product")
	public void addProduct(@RequestBody Product prod) {
		plantifyService.addProduct(prod);
	}
	
	@DeleteMapping("delete-product/{id}")
	public void deleteProduct(@PathVariable Long id) {
		plantifyService.deleteProduct(id);
	}
	
	@PutMapping("update-product/{id}")
	public void updateProduct(@RequestBody Product product , @PathVariable Long id ){
		plantifyService.updateProduct(product, id);
	}
	
	//contact
	@GetMapping("contact-info")
	public List<Contact> getContacts(){
		return plantifyService.getContact();
	}
	
	@PostMapping("add-contact-info")
	public void addContact(@RequestBody Contact info) {
		plantifyService.addContact(info);
	}
	
	@DeleteMapping("delete-contact-info/{id}")
	public void deleteContact(@PathVariable Long id) {
		plantifyService.deleteContact(id);
	}
	
	@PutMapping("update-contact-info/{id}")
	public void updateContactInfo(@RequestBody Contact info , @PathVariable Long id ){
		plantifyService.updateContactInfo(info, id);
	}
	
	//contact-us
	@GetMapping("messages")
	public List<ContactUs> getMessages(){
		return plantifyService.getMessages();
	}
	
	@PostMapping("add-message")
	public void addMessage(@RequestBody ContactUs msg) {
		plantifyService.addMessage(msg);
	}
	
	@DeleteMapping("delete-message/{id}")
	public void deleteMessage(@PathVariable Long id) {
		plantifyService.deleteMessage(id);
	}
	
	//customer
	@GetMapping("customers")
	public List<Customer> getCustomers(){
		return plantifyService.getCustomers();
	}
	
	@GetMapping("customer/{id}")
	public Customer getCustomerById(@PathVariable Long id){
		return plantifyService.getCustomerById(id);
	}
	
	@PostMapping("login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        Customer customer = plantifyService.verifyCustomer(email, password);

        if (customer != null) {
        	return ResponseEntity.ok(String.valueOf(customer.getCusId()));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
    }
	
	@PostMapping("add-customer")
	public void addCustomer(@RequestBody Customer cust) {
		plantifyService.addCustomer(cust);;
	}
	
	@DeleteMapping("delete-customer/{id}")
	public void deleteCustomer(@PathVariable Long id) {
		plantifyService.deleteCustomer(id);
	}
	
	@PutMapping("update-customer/{id}")
	public void updateCustomer(@RequestBody Customer cust , @PathVariable Long id ){
		plantifyService.updateCustomer(cust, id);
	}
	
	//reviews
	@GetMapping("reviews")
	public List<Review> getReviews(){
		return plantifyService.getReviews();
	}
	
	@GetMapping("reviews/{id}")
	public List<Review> getReviewsByProd(@PathVariable Long id){
		return plantifyService.getReviewsByProd(id);
	}
	
	@PostMapping("add-review")
	public void addReview(@RequestBody Review review) {
		plantifyService.addReview(review);
	}
	
	//product-added
	@GetMapping("products-added")
	public List<ProductAdded> getProductsAdded(){
		return plantifyService.getProductsAdded();
	}
	
	@GetMapping("products-added/{id}")
	public List<ProductAdded> getProductsAddedByCartId(@PathVariable Long id){
		return plantifyService.getProductsAddedByCartId(id);
	}
	
	@PostMapping("add-product-in-cart")
	public void addProductInCart(@RequestBody ProductAdded added) {
		plantifyService.addProductInCart(added);
	}
	
	@DeleteMapping("delete-product-in-cart/{id}")
	public void deleteProductInCart(@PathVariable Long id) {
		plantifyService.deleteProductInCart(id);
	}
	
	//cart
	@PostMapping("add-cart")
	public void addCart(@RequestBody Cart cart) {
		plantifyService.addCart(cart);
	}
	
	@GetMapping("cart/{id}")
	public Cart getCartByCusId(@PathVariable Long id){
		return plantifyService.getCartByCusId(id);
	}
	
	//blogComments
	@GetMapping("blog-comments")
	public List<BlogComment> getBlogComments(){
		return plantifyService.getBlogComments();
	}
	
	@GetMapping("blog-comments/{id}")
	public List<BlogComment> getBlogCommentsByBlogId(@PathVariable Long id){
		return plantifyService.getCommentsByBlogId(id);
	}
	
	@PostMapping("add-blog-comment")
	public void addBlogComment(@RequestBody BlogComment cmnt) {
		plantifyService.addBlogComment(cmnt);
	}
}


