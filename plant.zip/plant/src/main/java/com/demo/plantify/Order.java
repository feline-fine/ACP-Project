//package com.demo.plantify;
//
//import java.time.LocalDate;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.OneToOne;
//
//@Entity
//public class Order {
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
//	private int orderId;
//	
//	@OneToOne
//	@JoinColumn(name = "cartId", unique = true)
//	private Cart cart;
//	
////	@OneToMany
////	@JoinColumn(name = "cusId")
////	private Customer customer;
//	private double total;
//	private String note;
//	private LocalDate date;
//	private Customer status;
//}
