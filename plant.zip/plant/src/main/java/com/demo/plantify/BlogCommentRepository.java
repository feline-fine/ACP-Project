package com.demo.plantify;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface BlogCommentRepository extends CrudRepository<BlogComment, Long>{
	List<BlogComment> findByBlog_BlogId(Long blogId);
}
