package com.demo.plantify;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Testimonial {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int testimonialId;
	private String personName;
	private String personDp;
	private String personJob;
	private String company;
	
	@Column(columnDefinition = "MEDIUMTEXT")
	private String review;
	private String gender;
	
	private Testimonial() {
		super();
	}

	private Testimonial(String personName, String personDp, String personJob, String company, String review,
			String gender) {
		super();
		this.personName = personName;
		this.personDp = personDp;
		this.personJob = personJob;
		this.company = company;
		this.review = review;
		this.gender = gender;
	}

	public int getTestId() {
		return testimonialId;
	}

	public void setTestId(int testId) {
		this.testimonialId = testId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getPersonDp() {
		return personDp;
	}

	public void setPersonDp(String personDp) {
		this.personDp = personDp;
	}

	public String getPersonJob() {
		return personJob;
	}

	public void setPersonJob(String personJob) {
		this.personJob = personJob;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}	
}
