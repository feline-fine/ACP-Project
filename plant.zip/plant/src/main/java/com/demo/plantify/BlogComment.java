package com.demo.plantify;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class BlogComment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int commentId;
	
	@ManyToOne
	@JoinColumn(name = "blogId")
	private Blog blog;
	private String commentatorName;
	
	@Column(columnDefinition = "MEDIUMTEXT")
	private String comment;
	private LocalDate commentDate;
	
	private BlogComment() {
		super();
	}

	private BlogComment(int commentId, Blog blog, String commentatorName, String comment, LocalDate commentDate) {
		super();
		this.commentId = commentId;
		this.blog = blog;
		this.commentatorName = commentatorName;
		this.comment = comment;
		this.commentDate = commentDate;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public Blog getBlog() {
		return blog;
	}

	public void setBlog(Blog blog) {
		this.blog = blog;
	}

	public String getCommentatorName() {
		return commentatorName;
	}

	public void setCommentatorName(String commentatorName) {
		this.commentatorName = commentatorName;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public LocalDate getCommentDate() {
		return commentDate;
	}

	public void setCommentDate(LocalDate commentDate) {
		this.commentDate = commentDate;
	}	
}
