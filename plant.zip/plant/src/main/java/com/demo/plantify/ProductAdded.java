package com.demo.plantify;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class ProductAdded {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int addedId;
	
	@ManyToOne
	@JoinColumn(name = "cartId")
	private Cart cart;
	
	@ManyToOne
	@JoinColumn(name = "productId")
	private Product product;
	private int quantity;
	
	private ProductAdded() {
		super();
	}

	private ProductAdded(int addedId, Cart cart, Product product, int quantity) {
		super();
		this.addedId = addedId;
		this.cart = cart;
		this.product = product;
		this.quantity = quantity;
	}

	public int getAddedId() {
		return addedId;
	}

	public void setAddedId(int addedId) {
		this.addedId = addedId;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
