package com.demo.plantify;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

//import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlantifyService {
	@Autowired
	private BlogRepository blogRep;
	private CartRepository cartRep;
	private CategoryRepository catRep;
	private CustomerRepository custRep;
	private EditorRepository editorRep;
//	private OrderRepository orderRep;
	private ProductRepository prodRep;
//	private ReviewRepository revRep;
	private TeamRepository teamRep;
	private TestimonialRepository testRep;
	private ContactRepository contactRep;
	private ContactUsRepository msgRep;
	private ReviewRepository reviewRep;
	private ProductAddedRepository addedRep;
	private BlogCommentRepository bcRep;
	
//	private PlantifyService() {
//		super();
//	}

	//@Autowired
	private PlantifyService(BlogRepository blogRep, CategoryRepository catRep, EditorRepository editorRep,
			ProductRepository prodRep, TeamRepository teamRep, TestimonialRepository testRep, ContactRepository contactRep,
			CustomerRepository custRep, ContactUsRepository msgRep, CartRepository cartRep, ReviewRepository reviewRep,
			ProductAddedRepository addedRep, BlogCommentRepository bcRep) {
		super();
		this.blogRep = blogRep;
		this.catRep = catRep;
		this.editorRep = editorRep;
		this.prodRep = prodRep;
		this.teamRep = teamRep;
		this.testRep = testRep;
		this.contactRep = contactRep;
		this.custRep = custRep;
		this.msgRep = msgRep;
		this.cartRep = cartRep;
		this.reviewRep = reviewRep;
		this.addedRep = addedRep;
		this.bcRep = bcRep;
	}
	
	//team
	public List<Team> getTeam(){
		List<Team> team = new ArrayList();
		teamRep.findAll().forEach(team::add);
		return team;
	}
	
	public Team getTeamById(Long id) {
		return teamRep.findById(id).orElse(null);
    }

	public void addTeam (Team team) {
		teamRep.save(team);
	}
	
	public void deleteTeam(Long id) {
		teamRep.deleteById(id);
	}
	
	public void updateTeam(Team updatedMember, Long id) {
		Optional<Team> existingMemOptional = teamRep.findById(id);
		if (existingMemOptional.isPresent()) {
			Team existingMem = existingMemOptional.get();
			existingMem.setName(updatedMember.getName());
			existingMem.setEmail(updatedMember.getEmail());
			existingMem.setContact(updatedMember.getContact());
			existingMem.setPosition(updatedMember.getPosition());
			if(updatedMember.getMemberPic() !=null && !updatedMember.getMemberPic().isEmpty()) {
				existingMem.setMemberPic(updatedMember.getMemberPic());
			}
			teamRep.save(existingMem);
		}
	}
	
	//testimonials
	public List<Testimonial> getTest(){
		List<Testimonial> tests = new ArrayList();
		testRep.findAll().forEach(tests::add);
		return tests;
	}
	
	public Testimonial getTestById(Long id) {
		return testRep.findById(id).orElse(null);
    }
	
	public void addTest (Testimonial test) {
		testRep.save(test);
	}
	
	public void deleteTest(Long id) {
		testRep.deleteById(id);
	}
	
	public void updateTest(Testimonial updatedTest, Long id) {
		Optional<Testimonial> existingTestOptional = testRep.findById(id);
		if (existingTestOptional.isPresent()) {
			Testimonial existingTest = existingTestOptional.get();
			existingTest.setCompany(updatedTest.getCompany());
			existingTest.setPersonJob(updatedTest.getPersonJob());
			existingTest.setGender(updatedTest.getGender());
			existingTest.setPersonName(updatedTest.getPersonName());
			existingTest.setReview(updatedTest.getReview());
			if(updatedTest.getPersonDp() != null && !updatedTest.getPersonDp().isEmpty()) {
				existingTest.setPersonDp(updatedTest.getPersonDp());
			}
			testRep.save(existingTest);
		}
	}
	
	//blog
	public List<Blog> getBlog(){
		List<Blog> blogs = new ArrayList();
		blogRep.findAll().forEach(blogs::add);
		return blogs;
	}
	
	public void addBlog (Blog blog) {
		blogRep.save(blog);
	}
	
	public void deleteBlog(Long id) {
		blogRep.deleteById(id);
	}
	
	public Blog getBlogById(Long id) {
		return blogRep.findById(id).orElse(null);
    }
	
	public List<Blog> getRecentBlogs() {
        // Sort blogs by creation date in descending order
		List<Blog> blogs = new ArrayList();
		blogRep.findAll().forEach(blogs::add);
        List<Blog> sortedBlogs = blogs.stream()
                .sorted(Comparator.comparing(Blog::getCreationDate).reversed())
                .collect(Collectors.toList());

        // Get the specified number of recent blogs
        return sortedBlogs.stream().limit(3).collect(Collectors.toList());
    }
	
	public void updateBlog(Blog updatedBlog, Long id) {
		Optional<Blog> existingBlogOptional = blogRep.findById(id);
		if (existingBlogOptional.isPresent()) {
			Blog existingBlog = existingBlogOptional.get();
			existingBlog.setBlogQuote(updatedBlog.getBlogQuote());
			existingBlog.setContent(updatedBlog.getContent());
			existingBlog.setHeaderLine(updatedBlog.getHeaderLine());
			existingBlog.setCreationDate(updatedBlog.getCreationDate());
			existingBlog.setEditorId(updatedBlog.getEditorId());
			if(updatedBlog.getHeadImage() !=null && !updatedBlog.getHeadImage().isEmpty()) {
				existingBlog.setHeadImage(updatedBlog.getHeadImage());
			}
			blogRep.save(existingBlog);
		}
	}
	
	//editor
	public List<Editor> getEditor(){
		List<Editor> editors = new ArrayList();
		editorRep.findAll().forEach(editors::add);
		return editors;
	}
	
	public Editor getEditorById(Long id) {
		return editorRep.findById(id).orElse(null);
    }
	
	public void addEditor (Editor editor) {
		editorRep.save(editor);
	}
	
	public void deleteEditor(Long id) {
		editorRep.deleteById(id);
	}
	
	public void updateEditor(Editor updatedEditor, Long id) {
		Optional<Editor> existingEditorOptional = editorRep.findById(id);
		if (existingEditorOptional.isPresent()) {
			Editor existingEditor = existingEditorOptional.get();
			existingEditor.setName(updatedEditor.getName());
			existingEditor.setEmail(updatedEditor.getEmail());
			existingEditor.setContact(updatedEditor.getContact());
			existingEditor.setEditorNote(updatedEditor.getEditorNote());
			if(updatedEditor.getEditorDp() !=null && !updatedEditor.getEditorDp().isEmpty()) {
				existingEditor.setEditorDp(updatedEditor.getEditorDp());
			}
			editorRep.save(existingEditor);
		}
	}
	
	//product
	public List<Product> getTop3ProductsBySales() {
        // Sort products by sales in descending order
		List<Product> products = new ArrayList();
		prodRep.findAll().forEach(products::add);
        List<Product> sortedProducts = products.stream()
                .sorted(Comparator.comparingInt(Product::getSales).reversed())
                .collect(Collectors.toList());

        // Get the top 3 products
        return sortedProducts.stream().limit(3).collect(Collectors.toList());
    }
	
	public List<Product> getTop4ProductsByDate() {
        // Sort products by sales in descending order
		List<Product> products = new ArrayList();
		prodRep.findAll().forEach(products::add);
        List<Product> sortedProducts = products.stream()
                .sorted(Comparator.comparing(Product::getDate).reversed())
                .collect(Collectors.toList());

        // Get the top 3 products
        return sortedProducts.stream().limit(4).collect(Collectors.toList());
    }
	
	public List<Product> getProduct(){
		List<Product> products = new ArrayList();
		prodRep.findAll().forEach(products::add);
		return products;
	}
	
	public Product getProdById(Long id) {
		return prodRep.findById(id).orElse(null);
    }
	
	public List<Product> getProductsByCategoryId(Long id){
		return prodRep.findByCategory_CategoryId(id);
	}
	
	public void addProduct (Product product) {
		prodRep.save(product);
	}
	
	public void deleteProduct(Long id) {
		prodRep.deleteById(id);
	}
	
	public void updateProduct(Product updatedProd, Long id) {
		Optional<Product> existingProdOptional = prodRep.findById(id);
		if (existingProdOptional.isPresent()) {
			Product existingProd = existingProdOptional.get();
			existingProd.setName(updatedProd.getName());
			existingProd.setDescription(updatedProd.getDescription());
			existingProd.setPrice(updatedProd.getPrice());
			if(updatedProd.getImage() !=null && !updatedProd.getImage().isEmpty()) {
				existingProd.setImage(updatedProd.getImage());
			}
			existingProd.setOnSale(updatedProd.isOnSale());
			existingProd.setQuantityInStock(updatedProd.getQuantityInStock());
			existingProd.setSku(updatedProd.getSku());
			existingProd.setSales(updatedProd.getSales());
			existingProd.setStatus(updatedProd.getStatus());
			existingProd.setDate(updatedProd.getDate());
			existingProd.setInfo1(updatedProd.getInfo1());
			existingProd.setInfo2(updatedProd.getInfo2());
			existingProd.setInfo3(updatedProd.getInfo3());
			existingProd.setInfo4(updatedProd.getInfo4());
			
			prodRep.save(existingProd);
		}
	}

	//category
	public List<Category> getCategory(){
		List<Category> cats = new ArrayList();
		catRep.findAll().forEach(cats::add);
		return cats;
	}
	
	public Category getCategoryById(Long id){
		return catRep.findById(id).orElse(null);
	}
	
	public void addCategory (Category cat) {
		catRep.save(cat);
	}
	
	public void deleteCategory(Long id) {
		catRep.deleteById(id);
	}
	
	public void updateCategory(Category updatedCat, Long id) {
		Optional<Category> existingCatOptional = catRep.findById(id);
		if (existingCatOptional.isPresent()) {
			Category existingCat = existingCatOptional.get();
			existingCat.setName(updatedCat.getName());
			existingCat.setDescription(updatedCat.getDescription());
			catRep.save(existingCat);
		}
	}
	
	//contact
	public List<Contact> getContact(){
		List<Contact> info = new ArrayList();
		contactRep.findAll().forEach(info::add);
		return info;
	}
	
	public void addContact (Contact info) {
		contactRep.save(info);
	}
	
	public void deleteContact(Long id) {
		contactRep.deleteById(id);
	}
	
	public void updateContactInfo(Contact updatedInfo, Long id) {
		Optional<Contact> existingInfoOptional = contactRep.findById(id);
		if (existingInfoOptional.isPresent()) {
			Contact existingInfo = existingInfoOptional.get();
			existingInfo.setAddress(updatedInfo.getAddress());
			existingInfo.setPhone(updatedInfo.getPhone());
			existingInfo.setTagLine(updatedInfo.getTagLine());
			existingInfo.setOpenTime(updatedInfo.getOpenTime());
			existingInfo.setPhone(updatedInfo.getPhone());
			contactRep.save(existingInfo);
		}
	}
	
	//contact-us
	public List<ContactUs> getMessages(){
		List<ContactUs> messages = new ArrayList();
		msgRep.findAll().forEach(messages::add);
		return messages;
	}
	
	public void addMessage (ContactUs msg) {
		msgRep.save(msg);
	}
	
	public void deleteMessage(Long id) {
		msgRep.deleteById(id);
	}
	
	//customer
	public List<Customer> getCustomers(){
		List<Customer> custs = new ArrayList();
		custRep.findAll().forEach(custs::add);
		return custs;
	}
	
	public Customer getCustomerById(Long id) {
		return custRep.findById(id).orElse(null);
    }
	
	public Customer verifyCustomer(String email, String password) {
		List<Customer> custs = new ArrayList();
		custRep.findAll().forEach(custs::add);
        for(Customer cust: custs) {
        	if (cust != null && email.equals(cust.getCusEmail()) && password.equals(cust.getCusPass())) {
                return cust;
            }
        }
        return null; // Return null if verification fails
    }
	
	public void addCustomer (Customer cust) {
		custRep.save(cust);
	}
	
	public void deleteCustomer(Long id) {
		custRep.deleteById(id);
	}
	
	//reviews
	public List<Review> getReviews(){
		List<Review> reviews = new ArrayList();
		reviewRep.findAll().forEach(reviews::add);
		return reviews;
	}
	
	public void addReview (Review review) {
		reviewRep.save(review);
	}
	
	public List<Review> getReviewsByProd(Long id){
		return reviewRep.findByProduct_ProductId(id);
	}
	
	//products in cart
	public List<ProductAdded> getProductsAdded(){
		List<ProductAdded> added = new ArrayList();
		addedRep.findAll().forEach(added::add);
		return added;
	}
	
	public List<ProductAdded> getProductsAddedByCartId(Long id){
		return addedRep.findByCart_CartId(id);
	}
	
	public void addProductInCart (ProductAdded added) {
		addedRep.save(added);
	}
	
	public void deleteProductInCart(Long id) {
		addedRep.deleteById(id);
	}
	
	public void updateCustomer(Customer updatedCust, Long id) {
		Optional<Customer> existingCustOptional = custRep.findById(id);
		if (existingCustOptional.isPresent()) {
			Customer existingCust = existingCustOptional.get();
			existingCust.setCusName(updatedCust.getCusName());
			existingCust.setCusEmail(updatedCust.getCusEmail());
			custRep.save(existingCust);
		}
	}
	
	//cart
	public void addCart (Cart cart) {
		Long cusId = Long.parseLong(String.valueOf(cart.getCustomer().getCusId()));

	    if (cartRep.existsById(cusId)) {
	        cartRep.save(cart);
	    }
	}
	
	public Cart getCartByCusId(Long id) {
		return cartRep.findByCustomer_CusId(id);
    }
	
	public void updateCart(Cart updatedCart, Long id) {
		Optional<Cart> existingCartOptional = cartRep.findById(id);
		if (existingCartOptional.isPresent()) {
			Cart existingCart = existingCartOptional.get();
			existingCart.setTotalQty(updatedCart.getTotalQty());
			cartRep.save(existingCart);
		}
	}
	
	//blogComments
	public void addBlogComment (BlogComment cmnt) {
		bcRep.save(cmnt);
	}
	
	public List<BlogComment> getBlogComments(){
		List<BlogComment> cmnts = new ArrayList();
		bcRep.findAll().forEach(cmnts::add);
		return cmnts;
	}
	
	public List<BlogComment> getCommentsByBlogId(Long blogId) {
        return bcRep.findByBlog_BlogId(blogId);
    }
}
