package com.demo.plantify;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cusId;
	
	@OneToOne(mappedBy = "customer", cascade = CascadeType.ALL)
    private Cart cart;
	
	private String cusName;
	private String cusEmail;
	private String cusPass;
	private String cusPhone;
	private String company;
	private String cusAddress;
	private String cusCity;
	private String cusProvince;
	private String cusCountry;
	private String cusZip;
	
	private Customer() {
		super();
	}

	private Customer(int cusId, String cusName, String cusEmail, String cusPass, String cusPhone, String company,
			String cusAddress, String cusCity, String cusProvince, String cusCountry, String cusZip) {
		super();
		this.cusId = cusId;
		this.cusName = cusName;
		this.cusEmail = cusEmail;
		this.cusPass = cusPass;
		this.cusPhone = cusPhone;
		this.company = company;
		this.cusAddress = cusAddress;
		this.cusCity = cusCity;
		this.cusProvince = cusProvince;
		this.cusCountry = cusCountry;
		this.cusZip = cusZip;
	}

	public int getCusId() {
		return cusId;
	}

	public void setCusId(int cusId) {
		this.cusId = cusId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getCusEmail() {
		return cusEmail;
	}

	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}

	public String getCusPass() {
		return cusPass;
	}

	public void setCusPass(String cusPass) {
		this.cusPass = cusPass;
	}

	public String getCusPhone() {
		return cusPhone;
	}

	public void setCusPhone(String cusPhone) {
		this.cusPhone = cusPhone;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCusAddress() {
		return cusAddress;
	}

	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}

	public String getCusCity() {
		return cusCity;
	}

	public void setCusCity(String cusCity) {
		this.cusCity = cusCity;
	}

	public String getCusProvince() {
		return cusProvince;
	}

	public void setCusProvince(String cusProvince) {
		this.cusProvince = cusProvince;
	}

	public String getCusCountry() {
		return cusCountry;
	}

	public void setCusCountry(String cusCountry) {
		this.cusCountry = cusCountry;
	}

	public String getCusZip() {
		return cusZip;
	}

	public void setCusZip(String cusZip) {
		this.cusZip = cusZip;
	}	
}
