package com.demo.plantify;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface ReviewRepository extends CrudRepository<Review, Long>{
	List<Review> findByProduct_ProductId(Long productId);
}
