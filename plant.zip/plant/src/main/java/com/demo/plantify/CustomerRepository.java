package com.demo.plantify;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface CustomerRepository extends CrudRepository<Customer, Long>{

	//Customer findByCusEmail(String email);

}
