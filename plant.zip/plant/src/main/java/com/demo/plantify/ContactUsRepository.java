package com.demo.plantify;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface ContactUsRepository extends CrudRepository<ContactUs, Long>{

}
