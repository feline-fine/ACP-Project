package com.demo.plantify;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface BlogRepository extends CrudRepository<Blog, Long>{

}

