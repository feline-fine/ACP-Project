package com.demo.plantify;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

@Component
public interface CartRepository extends CrudRepository<Cart, Long>{
	Cart findByCustomer_CusId(Long cusId);
}
