package com.demo.plantify;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Blog {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int blogId;
	
	@ManyToOne
	@JoinColumn(name = "editorId")
	private Editor editorId;
	private String headerLine;

	@Column(columnDefinition = "LONGTEXT")
	private String content;
	
	@Column(columnDefinition = "MEDIUMTEXT")
	private String blogQuote;
	private String headImage;
	private LocalDate creationDate;
	
	private Blog() {
		super();
	}

	private Blog(String headerLine, String content, String blogQuote, String headImage, LocalDate creationDate) {
		super();
		this.headerLine = headerLine;
		this.content = content;
		this.blogQuote = blogQuote;
		this.headImage = headImage;
		this.creationDate = creationDate;
	}

	private Blog(int blogId, Editor editorId, String headerLine, String content, String blogQuote, String headImage,
			LocalDate creationDate) {
		super();
		this.blogId = blogId;
		this.editorId = editorId;
		this.headerLine = headerLine;
		this.content = content;
		this.blogQuote = blogQuote;
		this.headImage = headImage;
		this.creationDate = creationDate;
	}

	public int getBlogId() {
		return blogId;
	}

	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}

	public Editor getEditorId() {
		return editorId;
	}

	public void setEditorId(Editor editorId) {
		this.editorId = editorId;
	}

	public String getHeaderLine() {
		return headerLine;
	}

	public void setHeaderLine(String headerLine) {
		this.headerLine = headerLine;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getBlogQuote() {
		return blogQuote;
	}

	public void setBlogQuote(String blogQuote) {
		this.blogQuote = blogQuote;
	}

	public String getHeadImage() {
		return headImage;
	}

	public void setHeadImage(String headImage) {
		this.headImage = headImage;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}
	
}
