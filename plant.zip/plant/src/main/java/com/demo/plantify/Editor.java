package com.demo.plantify;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Editor {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int editorId;
	
	private String name;
	private String editorDp;
	private String email;
	private String editorNote;
	private String contact;
	
	private Editor() {
		super();
	}

	private Editor(String name, String editorDp, String email, String editorNote, String contact) {
		super();
		this.name = name;
		this.editorDp = editorDp;
		this.email = email;
		this.editorNote = editorNote;
		this.contact = contact;
	}

	public int getEditorId() {
		return editorId;
	}

	public void setEditorId(int editorId) {
		this.editorId = editorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEditorDp() {
		return editorDp;
	}

	public void setEditorDp(String editorDp) {
		this.editorDp = editorDp;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEditorNote() {
		return editorNote;
	}

	public void setEditorNote(String editorNote) {
		this.editorNote = editorNote;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
}
