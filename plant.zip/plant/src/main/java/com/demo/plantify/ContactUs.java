package com.demo.plantify;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
class ContactUs {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int messageId;
	
	private String name;
	private String email;
	private String subject;
	private String message;
	private LocalDate submissionDate;
	
	private ContactUs() {
		super();
	}

	private ContactUs(int messageId, String name, String email, String subject, String message,
			LocalDate submissionDate) {
		super();
		this.messageId = messageId;
		this.name = name;
		this.email = email;
		this.subject = subject;
		this.message = message;
		this.submissionDate = submissionDate;
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDate getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(LocalDate submissionDate) {
		this.submissionDate = submissionDate;
	}
}
