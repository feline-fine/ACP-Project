package com.demo.plantify;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cartId;
	
	@OneToOne()
	@JoinColumn(name = "cusId", unique = true)
	private Customer customer;
	
//	@OneToOne(mappedBy = "cart", cascade = CascadeType.ALL)
//    private Order order;
	
	private int totalQty;
	private int subtotal;
	
	private Cart() {
		super();
	}

	private Cart(int cartId, Customer customer, int totalQty, int subtotal) {
		super();
		this.cartId = cartId;
		this.customer = customer;
		//this.order = order;
		this.totalQty = totalQty;
		this.subtotal = subtotal;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

//	public Order getOrder() {
//		return order;
//	}
//
//	public void setOrder(Order order) {
//		this.order = order;
//	}

	public int getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(int totalQty) {
		this.totalQty = totalQty;
	}

	public int getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}
}
