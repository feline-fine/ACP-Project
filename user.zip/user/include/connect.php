<?php
  $server_name = "localhost";
  $username = "root";
  $password = "mhjiuo@12345";
  $db_name = "plantify";
  $conn = mysqli_connect($server_name, $username, $password, $db_name);

  if (!$conn) {
    die("Connection failed" . mysqli_connect_error());
  }
 ?>
