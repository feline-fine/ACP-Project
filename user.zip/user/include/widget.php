<div class="col-12 col-md-4">
    <div class="post-sidebar-area">

        <!-- ##### Single Widget Area ##### -->
        <div class="single-widget-area">
            <form action="#" method="get" class="search-form">
                <input type="search" name="search" id="widgetsearch" placeholder="Search...">
                <button type="submit"><i class="icon_search"></i></button>
            </form>
        </div>

        <!-- ##### Single Widget Area ##### -->
        <div class="single-widget-area">
            <!-- Title -->
            <div class="widget-title">
                <h4>Recent post</h4>
            </div>

            <!-- Single Latest Posts -->
            <div class="single-latest-post d-flex align-items-center">
                <div class="post-thumb">
                    <img src='img/bg-img/prod-2.jpg' alt='Blog Image'>
                </div>
                <div class="post-content">
                    <a href="#" class="post-title">
                        <h6>dff</h6>
                    </a>
                    <a href="#" class="post-date">{date formatted}</a>
                </div>
            </div>

        <!-- ##### Single Widget Area ##### -->
        <div class="single-widget-area">
            <!-- Title -->
            <div class="widget-title">
                <h4>Tag Cloud</h4>
            </div>
            <!-- Tags -->
            <ol class="popular-tags d-flex flex-wrap">
                <li><a href="#">PLANTS</a></li>
                <li><a href="#">NEW PRODUCTS</a></li>
                <li><a href="#">CACTUS</a></li>
                <li><a href="#">DESIGN</a></li>
                <li><a href="#">NEWS</a></li>
                <li><a href="#">TRENDING</a></li>
                <li><a href="#">VIDEO</a></li>
                <li><a href="#">GARDEN DESIGN</a></li>
            </ol>
        </div>

        <!-- ##### Single Widget Area ##### -->
        <div class="single-widget-area">
            <!-- Title -->
            <div class="widget-title">
                <h4>BEST SELLER</h4>
            </div>

            <!-- Single Best Seller Products -->
            <div class="single-best-seller-product d-flex align-items-center">
                <div class="product-thumbnail">
                    <a href="shop-details.html"><img src='img/bg-img/prod-1.jpg' alt='Product Image'></a>
                </div>
                <div class="product-info">
                    <a href="shop-details.html">farwa chan></a>
                    <p>2390</p>
                    <div class="ratings">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

