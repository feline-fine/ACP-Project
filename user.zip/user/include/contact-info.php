  <div class="contact-information">
      <p><span>Address:</span> <?php echo $in['address']; ?></p>
      <p><span>Phone:</span> <?php echo $in['phone']; ?></p>
      <p><span>Email:</span> <?php echo $in['email']; ?></p>
      <p><span>Open hours:</span> <?php echo $in['open_hours']; ?></p>
  </div>
