document.getElementById('contact-us-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission
        // Get form data using FormData
        const formData = new FormData(event.target);
    
    // Create an object in the required format
    const dataObject = {
        "name": formData.get('name'),
        "email": formData.get('email'),
        "subject": formData.get('subject'),
        "message": formData.get('message'),
        "submissionDate": new Date().toISOString().split('T')[0]
    }
    fetch('http://localhost:8080/api/plantify/add-message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        // Check if the response status is OK
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Since we don't expect a JSON response, return an empty object
        return {};
    })
    .then(data => {
        console.log('Success:', data);
        // Handle success, e.g., show a success message to the user
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });

});