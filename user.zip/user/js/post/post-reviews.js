
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('submit-review-btn').addEventListener('click', submitReview);
});

function submitReview(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get form data using FormData
    const formData = new FormData(document.getElementById('review-form'));

    // Extract productId from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('productId');

    const cusId = localStorage.getItem('customerId');
    console.log('Customer ID:', cusId);

    // Get stars rating
    const stars = getSelectedStarValue();

    // Create an object in the required format
    const reviewObject = {
        "product": {
            "productId": parseInt(productId)
        },
        "customer": {

            "cusId": cusId // Assuming cusId is always 1 for now
        },
        "stars": parseInt(stars),
        "nickname": formData.get('nickname'),
        "reason": formData.get('reason'),
        "comment": formData.get('comment'),
        "date": new Date().toISOString().slice(0, 10)
    };

    // Your fetch request here...
    // Example:
    fetch('http://localhost:8080/api/plantify/add-review', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify(reviewObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
        // Add any additional logic here after successful review submission
        window.location.reload(); // reload the page
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });
}

function getSelectedStarValue() {
    const stars = document.querySelectorAll('.stars input[type="radio"]');
    for (const star of stars) {
        if (star.checked) {
            return star.value;
        }
    }
    return 0; // Default value if no star is selected
}