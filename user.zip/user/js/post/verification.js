document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission
    
    // Get form data using FormData
    const formData = new FormData(event.target);

    // Create an object in the required format
    const loginRequest = {
        "email": formData.get('email'),
        "password": formData.get('password')
    };

    // Make a Fetch API request to your server
    fetch('http://localhost:8080/api/plantify/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginRequest),
    })
    .then(response => {
        // Check if the response status is OK
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Assuming the server returns the customer ID as text
        return response.text();
    })
    .then(customerId => {
        console.log('Login successful! Customer ID:', customerId);
        
        // Redirect to index.html

        // Store customer ID in localStorage
        localStorage.setItem('customerId', customerId);

        // Redirect to another page
        window.location.href = 'index.html'; // Redirect to your home page or any other page


        // Optionally, you can store the customer ID in localStorage or sessionStorage for future use
        // localStorage.setItem('cusId', customerId);
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });
});
