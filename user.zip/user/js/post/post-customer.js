document.getElementById('signup-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission
        // Get form data using FormData
        const formData = new FormData(event.target);
    
    // Create an object in the required format
    const dataObject = {
        "cusName": formData.get('name'),
        "cusEmail": formData.get('email'),
        "cusPass": formData.get('password')

    }
    fetch('http://localhost:8080/api/plantify/add-customer', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            "Access-Control-Allow-Origin" : "*", 
            "Access-Control-Allow-Credentials" : true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        // Check if the response status is OK
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Since we don't expect a JSON response, return an empty object
        return {};
    })
    .then(customer => {
        console.log('Success:', customer);
        // Redirect to index.html with customer id as query parameter
        const indexURL = `login.html`;
        window.location.href = indexURL;
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });

});