function getCartId() {
    const cusId = localStorage.getItem('customerId');
    console.log('Customer ID:', cusId);

    // Check if a cart already exists for the customer
    return fetch(`http://localhost:8080/api/plantify/cart/${cusId}`, {
        method: 'GET',
        headers: {
            'content-type': 'application/json',
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        // Check if response is empty or not JSON
        return response.json().catch(() => ({}));
    })
    .then(cart => {
        // If cart doesn't exist or response is empty, create a new one
        if (!cart || Object.keys(cart).length === 0) {
            return cart.cartId;
        } else {
            return null;
        }
    })
    .catch(error => {
        console.error('Error checking cart:', error);
    });
}


document.addEventListener('DOMContentLoaded', function () {
    // Extract product ID from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const prodId = urlParams.get('productId');

    // Add event listener to the "Add to Cart" form
    document.getElementById('add-to-cart-form').addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get quantity from the input field
        const quantity = parseInt(document.getElementById('qty').value);

        //checking thru console if the cartId is null or not
        getCartId().then(cartId => {
            if (cartId != null) {
                console.log(cartId);
            } else {
                console.log("user needs to log-in first");
            }
        });

        // Create an object in the required format
        const productAddedObject = {
            "cart": {
                "cartId": 1 // Assuming cartId is always 1 for now
            },
            "product": {
                "productId": parseInt(prodId)
            },
            "quantity": quantity
        };

        // Make a Fetch API request to add the product to the cart
        fetch('http://localhost:8080/api/plantify/add-product-in-cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': true
            },
            body: JSON.stringify(productAddedObject),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return {};
        })
        .then(data => {
            console.log('Product added to cart successfully:', data);
            // You can add any additional logic here after successful product addition
        })
        .catch((error) => {
            console.error('Error:', error.message);
            // Handle errors, e.g., show an error message to the user
        });
    });
});
