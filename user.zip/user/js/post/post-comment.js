document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('post-comment-btn').addEventListener('click', postComment);
});

function postComment(event) {
    event.preventDefault(); // Prevent the default form submission

    // Get form data using FormData
    const formData = new FormData(document.getElementById('comment-box'));

    // Extract blogId from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const blogId = urlParams.get('blogId');

    // Create an object in the required format
    const dataObject = {
        "blog": {
            "blogId": parseInt(blogId)
        },
        "commentatorName": formData.get('name'),
        "comment": formData.get('comment'),
        "commentDate": new Date().toISOString().slice(0, 10)
    };

    // Your fetch request here...
    // Example:
    fetch('http://localhost:8080/api/plantify/add-blog-comment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify(dataObject),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return {};
    })
    .then(data => {
        console.log('Success:', data);
        // Add any additional logic here after successful comment submission
        window.location.reload(); // reload the page
    })
    .catch((error) => {
        console.error('Error:', error.message);
        // Handle errors, e.g., show an error message to the user
    });
}
