// Assuming this function is called when a blog post is clicked
function handleBlogClick(blogId) {
    // Construct the URL with the blogId
    const singlePostURL = `single-post.html?blogId=${blogId}`;
    // Navigate to the single-post.html page
    window.location.href = singlePostURL;
}

const urlParams = new URLSearchParams(window.location.search);
const blogId = urlParams.get('blogId');

document.addEventListener('DOMContentLoaded', function () {
    // Extract blogId from the URL
    

    // Fetch blog details based on the blogId
    fetch(`http://localhost:8080/api/plantify/blogs/${blogId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(spec => {
            // Update HTML content with fetched data
            console.log(spec);
            document.querySelector('.post-title').innerText = spec.headerLine;
            document.querySelector('.post-meta a:nth-child(1)').innerText = spec.creationDate;
            document.querySelector('.post-meta a:nth-child(2)').innerText = spec.editorId.name;
            document.querySelector('.post-thumbnail img').src = `img/bg-img/${spec.headImage}`;
            document.querySelector('.post-content p').innerText = spec.content;
            document.querySelector('.blockquote-text h5:first-child').innerText = spec.blogQuote;

            document.getElementById('editorName').innerText = spec.editorId.name;
            document.getElementById('editorNote').innerText = spec.editorId.editorNote;
            document.getElementById('editorImage').setAttribute('src', `img/bg-img/${spec.editorId.editorDp}`);
        })
        .catch(error => {
            console.error('Error fetching blog details:', error);
        });
});

function fetchComments() {

    fetch(`http://localhost:8080/api/plantify/blog-comments/${blogId}`, {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(comments => {
            // Handle the retrieved data
            console.log(comments);

            // Select the containers for blog posts and pagination
            let commentList = document.getElementById('comment-list');

            // Loop through the data and create HTML elements for each blog
            comments.forEach(comment => {
                // Create a new blog element
                let listItem = document.createElement('li');
                listItem.className = "single_comment_area";
                listItem.innerHTML = `
                    <div class="comment-wrapper d-flex">
                        <!-- Comment Meta -->
                        <div class="comment-author">
                            <img src="img/bg-img/profile.jpg" alt="">
                        </div>
                        <!-- Comment Content -->
                        <div class="comment-content">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5>${comment.commentatorName}</h5>
                                <span class="comment-date">${comment.commentDate}</span>
                            </div>
                            <p>${comment.comment}</p>
                            <a class="active" href="#">Reply</a>
                        </div>
                    </div>
                `;

                // Append the blog post to the blog container
                commentList.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

