function fetchTeam() {
    fetch('http://localhost:8080/api/plantify/team', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Handle the retrieved data
            console.log(data);

            // Select the team container
            let teamContainer = document.querySelector('.team-area .row');

            // Loop through the data and create HTML elements for each team member
            data.forEach(member => {
                // Create a new team member element
                let teamMember = document.createElement('div');
                teamMember.className = 'col-12 col-sm-6 col-lg-3';

                // HTML template for a team member
                teamMember.innerHTML = `
                    <div class="single-team-member text-center mb-100">
                        <div class="team-member-thumb">
                            <img src='img/bg-img/${member.memberPic}' alt='Team Image'>
                            <div class="team-member-social-info">
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <div class="team-member-info mt-30">
                            <h5>${member.name}</h5>
                            <p>${member.position}</p>
                        </div>
                    </div>
                `;

                // Append the team member to the team container
                teamContainer.appendChild(teamMember);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

//testimonials
function fetchTestimonials() {
    fetch('http://localhost:8080/api/plantify/testimonials', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(testimonials => {
        // Handle the retrieved data
        console.log(testimonials);

        // Select the testimonials container
        let testimonialsContainer = document.querySelector('.testimonials-slides');

        // Loop through the data and create HTML elements for each testimonial
        testimonials.forEach(testimonial => {
            // Create a new testimonial element
            let testimonialSlide = document.createElement('div');
            testimonialSlide.className = 'single-testimonial-slide';

            // HTML template for a testimonial
            testimonialSlide.innerHTML = `
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="testimonial-thumb">
                            <img src='img/bg-img/${testimonial.personDp}' alt='Testimonial Image'>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="testimonial-content">
                            <div class="section-heading">
                                <h2>${testimonial.personName}</h2>
                                <p>${testimonial.company} - ${testimonial.personJob}</p>
                            </div>
                            <p>${testimonial.review}</p>
                            <div class="testimonial-author-info">
                                <h6>${testimonial.gender === 'female' ? 'Ms.' : 'Mr.'} ${testimonial.personName}</h6>
                                <p>${testimonial.personJob} at ${testimonial.company}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            // Append the testimonial to the testimonials container
            testimonialsContainer.appendChild(testimonialSlide);
        });

            // Initialize the Owl Carousel after dynamically adding testimonials
            $('.testimonials-slides').owlCarousel({
                loop: true,
                nav: false,
                dots: true,
                items: 1,
                autoplay: true,
                autoplayTimeout: 5000,
                autoplayHoverPause: true
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}