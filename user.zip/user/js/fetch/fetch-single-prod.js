const urlParams = new URLSearchParams(window.location.search);
const prodId = urlParams.get('productId');

document.addEventListener('DOMContentLoaded', function () {   

    // Fetch blog details based on the blogId
    fetch(`http://localhost:8080/api/plantify/products/${prodId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(prod => {
            // Update HTML content with fetched data
            console.log(prod);
            document.getElementById('name').innerText = prod.name;
            document.getElementById('price').innerText = "Rs. " + prod.price;
            document.getElementById('description').innerText = prod.description;
            
            document.getElementById('sku').innerText = prod.sku;
            document.getElementById('category').innerText = prod.category.name;
            document.getElementById('imagepro').setAttribute('src', `img/bg-img/${prod.image}`);
            document.getElementById('descArea').innerText = prod.description;
            document.getElementById('info-1').innerText = prod.info1;
            document.getElementById('info-2').innerText = prod.info2;
            document.getElementById('info-3').innerText = prod.info3;
            document.getElementById('info-4').innerText = prod.info4;
        })
        .catch(error => {
            console.error('Error fetching product details:', error);
        });
});

function fetchReviews() {
    fetch(`http://localhost:8080/api/plantify/reviews/${prodId}`, {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(reviews => {
            // Handle the retrieved data
            console.log(reviews);

            // Select the containers for blog posts and pagination
            let reviewList = document.getElementById('review-list');

            // Loop through the data and create HTML elements for each blog
            reviews.forEach(review => {
                // Create a new blog element
                let listItem = document.createElement('li');
                listItem.innerHTML = `
                    <div class="single_user_review">
                        <div class="review-rating">
                            ${generateStarIcons(review.stars)}
                            <span>for ${review.reason}</span>
                        </div>
                        <div class="review-details">
                            <p>by ${review.nickname}</a> on <span>${review.date}</span></p>
                        </div>
                    </div>
                `;

                // Append the blog post to the blog container
                reviewList.appendChild(listItem);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

function generateStarIcons(starCount) {
    const starIcons = Array.from({ length: 5 }, (_, index) => {
        const starClass = index < starCount ? 'fa-star' : 'fa-star-o'; // Use 'fa-star' for filled stars and 'fa-star-o' for unfilled stars
        return `<i class="fa ${starClass}" aria-hidden="true"></i>`;
    });

    return starIcons.join('');
}



