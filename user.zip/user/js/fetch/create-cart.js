document.addEventListener('DOMContentLoaded', function () {
    // Extracting customer id from the local storage
    const cusId = localStorage.getItem('customerId');
    console.log('Customer ID:', cusId);

    // Check if a cart already exists for the customer
    fetch(`http://localhost:8080/api/plantify/cart/${cusId}`, {
        method: 'GET',
        headers: {
            'content-type': 'application/json',
        },
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        // Check if response is empty or not JSON
        return response.json().catch(() => ({}));
    })
    .then(cart => {
        // If cart doesn't exist or response is empty, create a new one
        if (!cart || Object.keys(cart).length === 0) {
            createCart(cusId);
        } else {
            console.log('Cart exists:', cart);
        }
    })
    .catch(error => {
        console.error('Error checking cart:', error);
    });
});

function createCart(cusId) {
    // Create a new cart for the customer
    const cartData = {
        "subtotal": null,
        "totalQty": null,
        "customer": {
            "cusId": cusId
        }
    };

    fetch('http://localhost:8080/api/plantify/add-cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(cartData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(newCart => {
        console.log('New cart created:', newCart);
    })
    .catch(error => {
        console.error('Error creating cart:', error);
    });
}
