function fetchTestimonials() {
    fetch('http://localhost:8080/api/plantify/testimonials', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(testimonials => {
        // Handle the retrieved data
        console.log(testimonials);

        // Select the testimonials container
        let testContainer = document.getElementById('test-container');

        // Loop through the data and create HTML elements for each testimonial
        testimonials.forEach(testimonial => {
            // Create a new testimonial element
            let testimonialSlide = document.createElement('div');
            testimonialSlide.className = 'single-testimonial-slide';

            // HTML template for a testimonial
            testimonialSlide.innerHTML = `
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="testimonial-thumb">
                            <img src='img/bg-img/${testimonial.personDp}' alt='Testimonial Image'>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="testimonial-content">
                            <div class="section-heading">
                                <h2>${testimonial.personName}</h2>
                                <p>${testimonial.company} - ${testimonial.personJob}</p>
                            </div>
                            <p>${testimonial.review}</p>
                            <div class="testimonial-author-info">
                                <h6>${testimonial.gender === 'female' ? 'Ms.' : 'Mr.'} ${testimonial.personName}</h6>
                                <p>${testimonial.personJob} at ${testimonial.company}</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            // Append the testimonial to the testimonials container
            testContainer.appendChild(testimonialSlide);
        });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// Call the fetchTestimonials function when the page loads or as needed
window.onload = function() {
    fetchTestimonials();
};