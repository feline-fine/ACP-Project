function handleProductClick(prodId) {
    // Construct the URL with the blogId
    const singleProdURL = `shop-details.html?productId=${prodId}`;
    // Navigate to the single-post.html page
    window.location.href = singleProdURL;
}
function fetchBestSellers() {
    fetch('http://localhost:8080/api/plantify/products-best-3', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(products => {
            // Handle the retrieved data
            console.log(products);

            // Select the containers for blog posts and pagination
            let bestSellersContainer = document.getElementById('best-sellers');
            let header = document.createElement('div');
            header.className = 'widget-title';
            header.innerHTML = '<h5>BEST SELLER</h5>';
            bestSellersContainer.appendChild(header);
            // Loop through the data and create HTML elements for each blog
            products.forEach(prod => {
                // Create a new blog element
                let product = document.createElement('div');
                product.className = 'single-best-seller-product d-flex align-items-center';
                product.innerHTML = `
                    <div class="product-thumbnail">
                        <a href="#" onclick="handleProductClick(${prod.productId})"><img src="img/bg-img/${prod.image}" alt=""></a>
                    </div>
                    <div class="product-info">
                        <a href="shop-details.html">${prod.name}</a>
                        <p>Rs. ${prod.price}</p>
                    </div>
                `;

                // Append the blog post to the blog container
                bestSellersContainer.appendChild(product);
            });

            // Move the pagination container to the bottom
            //blogContainer.parentNode.insertBefore(paginationContainer, blogContainer.nextSibling);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// // Call the fetchBlogs function when the page loads or as needed
// window.onload = function() {
//     fetchContact();
// };