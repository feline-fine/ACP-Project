// Assuming this function is called when a blog post is clicked
function handleProdClick(productId) {
    const singleProdURL = `shop-details.html?productId=${productId}`;
    // Navigate to the single-post.html page
    window.location.href = singleProdURL;
}

function fetchProducts() {
    fetch('http://localhost:8080/api/plantify/products', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(products => {
            // Handle the retrieved data
            console.log(products);

            // Select the containers for blog posts and pagination
            let prodContainer = document.getElementById('product-container');

            // Loop through the data and create HTML elements for each blog
            products.forEach(prod => {
                // Create a new blog element
                let productPost = document.createElement('div');
                productPost.className = 'col-12 col-sm-6 col-lg-4';
                productPost.innerHTML = `
                        <div class="single-product-area mb-50 wow fadeInUp" data-wow-delay="100ms">
                            <!-- Product Image -->
                            <div class="product-img">
                                <a href="#" onclick="handleProdClick(${prod.productId})"><img src='img/bg-img/${prod.image}' alt='Product Image'></a>
                                <!-- Product Tag -->
                                <div class="product-tag"><a href="#">Hot</a></div>
                                <div class="product-meta d-flex">
                                    <a href="#" class="wishlist-btn"><i class="icon_heart_alt"></i></a>
                                    <a href="cart.html" class="add-to-cart-btn">Add to cart</a>
                                    <a href="#" class="compare-btn"><i class="arrow_left-right_alt"></i></a>
                                </div>
                            </div>
                            <!-- Product Info -->
                            <div class="product-info mt-15 text-center">
                                <a href="#" onclick="handleProdClick(${prod.productId})">
                                    <p>${prod.name}</p>
                                </a>
                                <h6>Rs. ${prod.price}</h6>
                            </div>
                        </div>
                `;

                // Append the blog post to the blog container
                prodContainer.appendChild(productPost);
            });

            // Move the pagination container to the bottom
            //blogContainer.parentNode.insertBefore(paginationContainer, blogContainer.nextSibling);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}
