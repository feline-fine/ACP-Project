function fetchContact() {
    fetch('http://localhost:8080/api/plantify/contact-info', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(infos => {
            // Handle the retrieved data
            console.log(infos);

            // Select the containers for blog posts and pagination
            let contactContainer = document.getElementById('contact-info');

            // Loop through the data and create HTML elements for each blog
            infos.forEach(info => {
                // Create a new blog element
                let contact = document.createElement('div');
                contact.className = 'single-footer-widget';
                contact.innerHTML = `
                <div class="widget-title">
                    <h5>CONTACT</h5>
                </div>

                <div class="contact-information">
                    <p><span>Address: ${info.address}</p>
                    <p><span>Phone: ${info.phone}</p>
                    <p><span>Email: plantify@gmail.com</p>
                    <p><span>Open hours: ${info.openTime} - ${info.closeTime}</span></p>
                </div>
                `;

                // Append the blog post to the blog container
                contactContainer.appendChild(contact);
            });

            // Move the pagination container to the bottom
            //blogContainer.parentNode.insertBefore(paginationContainer, blogContainer.nextSibling);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// // Call the fetchBlogs function when the page loads or as needed
// window.onload = function() {
//     fetchContact();
// };