// function deleteProduct(prodId) {
//     // Confirm with the user before deleting the blog
//     const isConfirmed = confirm('Are you sure you want to delete this blog?');

//     if (isConfirmed) {
//         // Send a DELETE request to your API to delete the blog with the specified ID
//         fetch(`http://localhost:8080/api/plantify/delete-product/${prodId}`, {
//             method: 'DELETE',
//             headers: {
//                 'content-type': 'application/json',
//                 // Add any other headers as needed
//             },
//         })
//         .then(response => {
//             if (!response.ok) {
//                 throw new Error('Network response was not ok');
//             }
//             // Reload the page or update the blog list after successful deletion
//             location.reload();
//         })
//         .catch(error => {
//             console.error('Error during delete operation:', error);
//         });
//     }
// }

// //click on update button.
// function updateClick(prodId) {
//     // Construct the URL with the blogId
//     const updateProdURL = `update-product.html?productId=${prodId}`;
//     // Navigate to the single-post.html page
//     window.location.href = updateProdURL;
// }

function fetchProductsInCart() {
    fetch(`http://localhost:8080/api/plantify/products-added/1`, {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(products => {
            // Handle the retrieved data
            console.log(products);

            // Select the containers for blog posts and pagination
            let prodTable = document.getElementById('prod-table');

            // Loop through the data and create HTML elements for each blog
            products.forEach(added => {
                // Create a new blog element
                let prodRow = document.createElement('tr');
                prodRow.innerHTML = `
                <tr>
                    <td class="cart_product_img">
                        <a href="#"><img src="img/bg-img/${added.product.image}" alt="Product"></a>
                        <h5>${added.product.name}</h5>
                    </td>
                    <td class="qty">
                        <div class="quantity">
                            <span class="qty-minus" ><i class="fa fa-minus" aria-hidden="true"></i></span>
                            <input type="number" class="qty-text" id="qty" step="1" min="1" max="99" name="quantity" value="1">
                            <span class="qty-plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        </div>
                    </td>
                    <td class="price"><span>Rs. ${added.product.price}</span></td>
                    <td class="total_price">Rs. ${(added.product.price * added.quantity).toFixed(2)}</span></td>
                    <td class="action"><a href="#"><i class="icon_close"></i></a></td>
                </tr>
                `;

                // Append the prod row to the prob Table.
                prodTable.appendChild(prodRow);
            });
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}