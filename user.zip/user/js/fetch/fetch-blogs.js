// Assuming this function is called when a blog post is clicked
function handleBlogClick(blogId) {
    // Construct the URL with the blogId
    const singlePostURL = `single-post.html?blogId=${blogId}`;
    // Navigate to the single-post.html page
    window.location.href = singlePostURL;
}

function fetchBlogs() {
    fetch('http://localhost:8080/api/plantify/blogs', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(blogs => {
            // Handle the retrieved data
            console.log(blogs);

            // Select the containers for blog posts and pagination
            let blogContainer = document.getElementById('blogContainer');
            let paginationContainer = document.getElementById('paginationContainer');

            // Loop through the data and create HTML elements for each blog
            blogs.forEach(blog => {
                // Create a new blog element
                let blogPost = document.createElement('div');
                blogPost.className = 'col-12 col-lg-6';
                blogPost.innerHTML = `
                    <div class="single-blog-post mb-50">
                        <div class="post-thumbnail mb-30">
                            <a href="#" onclick="handleBlogClick(${blog.blogId})"><img src='img/bg-img/${blog.headImage}' alt='Blog Image'></a>
                        </div>
                        <div class="post-content">
                        <a href="#" onclick="handleBlogClick(${blog.blogId})" class="post-title">
                                <h5>${blog.headerLine}</h5>
                            </a>
                            <div class="post-meta">
                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i>
                                    ${formatDate(blog.creationDate)}
                                </a>
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i>${blog.editorId.name}</a>
                            </div>
                            <p class="post-excerpt">
                                ${truncateText(blog.content)}
                            </p>
                        </div>
                    </div>
                `;

                // Append the blog post to the blog container
                blogContainer.appendChild(blogPost);
            });

            // Move the pagination container to the bottom
            //blogContainer.parentNode.insertBefore(paginationContainer, blogContainer.nextSibling);
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

//contact


// Call the fetchBlogs function when the page loads or as needed
window.onload = function() {
    fetchBlogs();
};

// Helper function to format date
function formatDate(dateString) {
    // Implement your date formatting logic here
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Helper function to truncate text
function truncateText(text) {
    // Implement your text truncation logic here
    const periodIndex = text.indexOf('.'); // Find the index of the first period

    if (periodIndex !== -1) {
        return text.substring(0, periodIndex + 1); // Return the content until the first period (including the period)
    } else {
        return text; // Return the original text if no period is found
    }
}




