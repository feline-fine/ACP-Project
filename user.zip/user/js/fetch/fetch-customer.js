document.addEventListener('DOMContentLoaded', function () {
    // Extract cusId from the URL
    const cusId = localStorage.getItem('customerId');
    console.log('Customer ID:', cusId);

    // Select the dropdown and items
    const dropdown = document.querySelector('.dropdown');
    const loginItem = document.querySelector('.dropdown-item[href="login.html"]');
    const registerItem = document.querySelector('.dropdown-item[href="register.html"]');
    const logoutItem = document.getElementById('logout');

    // Fetch customer details based on cusId
    if (cusId) {
        // User is logged in
        fetch(`http://localhost:8080/api/plantify/customer/${cusId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(customer => {
                // Update HTML content with fetched data
                console.log(customer);
                document.getElementById('profileName').innerText = `   ${customer.cusName}`;
            })
            .catch(error => {
                console.error('Error fetching customer details:', error);
            });

        // Hide login and register, show logout
        loginItem.style.display = 'none';
        registerItem.style.display = 'none';
        logoutItem.style.display = 'block';
    } else {
        // User is not logged in
        // Hide logout, show login and register
        loginItem.style.display = 'block';
        registerItem.style.display = 'block';
        logoutItem.style.display = 'none';
    }
});
