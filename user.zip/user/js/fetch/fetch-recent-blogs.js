//recent blogs
function fetchRecentBlogs() {
    fetch('http://localhost:8080/api/plantify/recent-blogs', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(recents => {
            // Handle the retrieved data
            console.log(recents);

            // Assuming recents is an array of recent blog objects
            const recentBlogContainer = document.getElementById("recent-blogs-widget");

            // Limit the loop to the first 3 recent blogs
            for (let i = 0; i < Math.min(3, recents.length); i++) {
                const recentBlog = recents[i];

                // Create a new element for each recent blog
                let blogElement = document.createElement('div');
                blogElement.className = 'single-latest-post d-flex align-items-center';
                blogElement.innerHTML = `
                    <div class="post-thumb">
                        <img src='img/bg-img/${recentBlog.headImage}' alt='Blog Image'>
                    </div>
                    <div class="post-content">
                        <a href="#" onclick="handleBlogClick(${recentBlog.blogId})" class="post-title">
                            <h6>${recentBlog.headerLine}</h6>
                        </a>
                        <a href="#" class="post-date">${recentBlog.creationDate}</a>
                    </div>
                `;

                // Append the recent blog element to the container
                recentBlogContainer.appendChild(blogElement);
            }
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

// Call the fetchRecentBlogs function when the page loads or as needed
