// // Assuming this function is called when a blog post is clicked
// function handleProdClick(productId) {
//     const singleProdURL = `shop-details.html?productId=${productId}`;
//     // Navigate to the single-post.html page
//     window.location.href = singleProdURL;
// }

function fetchCategories() {
    fetch('http://localhost:8080/api/plantify/categories', {
            method: 'GET',
            headers: {
                'content-type': 'application/json',
                // Add any other headers as needed
            },
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(cats => {
            // Handle the retrieved data
            console.log(cats);

            // Select the dropdown element
            const categoryDropdown = document.getElementById('category-dropdown');

            // Loop through the data and create dropdown option for each category
            cats.forEach(cat => {
                // Create a new option element
                const option = document.createElement('option');
                option.value = cat.categoryId; // Assuming categoryId is the property containing the category ID
                option.text = cat.name; // Assuming categoryName is the property containing the category name

                // Append the option to the dropdown
                categoryDropdown.appendChild(option);
            })
        })
        .catch(error => {
            console.error('Error during fetch operation:', error);
        });
}

